package Notificaitons;

public class MyResponse {
    public int success;
}
