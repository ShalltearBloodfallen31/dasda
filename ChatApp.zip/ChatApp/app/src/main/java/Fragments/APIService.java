package Fragments;

import Notificaitons.MyResponse;
import Notificaitons.Sender;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.Headers;
import retrofit2.http.POST;

public interface APIService {

    @Headers(

            {

                    "Content-Type:application/json",
                    "Authorization:key=AAAAS7zh1iw:APA91bEmrnzbHQpjhnZPee1m5313HKqbtzcklC72kqnnoKPuxxRtEF-FJ95h1_3OXbgqvQidpeX9i3mtYWqPkOu1LjtEurNQow2RPhmETuyBfq9dU1Srkoy5OrLNUVNmjiy1jOjRpyPU"
            }

    )

    @POST("fcm/send")
    Call<MyResponse> sendNotifications(@Body Sender body);

}
